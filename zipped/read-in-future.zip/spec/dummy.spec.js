describe("A dummy test", function() {
  it("contains spec with an expectation", function() {
    expect(true).toBe(true);
  });
});