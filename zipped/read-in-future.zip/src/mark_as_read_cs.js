/** Contains all of the code for the content_script to be used in those
	pages that were added to the database to be read latter. 
*/

